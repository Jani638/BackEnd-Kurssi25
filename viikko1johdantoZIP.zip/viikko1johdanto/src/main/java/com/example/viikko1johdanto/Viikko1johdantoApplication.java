package com.example.viikko1johdanto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Viikko1johdantoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Viikko1johdantoApplication.class, args);
	}

}
