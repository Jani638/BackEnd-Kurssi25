package com.example.viikko1johdanto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Viikko1johdantoApplicationTests {

	@Test
	void contextLoads() {
	}

}
